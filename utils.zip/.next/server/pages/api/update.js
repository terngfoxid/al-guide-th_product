"use strict";
(() => {
var exports = {};
exports.id = 901;
exports.ids = [901];
exports.modules = {

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 3281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6173);

async function handler(req, res) {
    const snapshot_d = await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].collection */ .Z.collection("data_update").orderBy("id", "desc").limit(5).get();
    const snapshot_w = await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].collection */ .Z.collection("web_update").orderBy("id", "desc").limit(5).get();
    const data = {
        data_update: [],
        web_update: []
    };
    if (snapshot_d.empty && snapshot_w.empty) {
        {
            res.status(404).json({
                error: "Not Found Update Data"
            });
        }
    }
    if (snapshot_d.empty) {
        data.data_update = {
            error_d: "Not Found Data Update"
        };
    } else {
        snapshot_d.forEach((doc)=>{
            data.data_update.push(doc.data());
        });
    }
    if (snapshot_w.empty) {
        data.data_update = {
            error_w: "Not Found Web Update"
        };
    } else {
        snapshot_w.forEach((doc)=>{
            data.web_update.push(doc.data());
        });
    }
    if (data == null) {
        res.status(404).json({
            error: "Not Found Update Data"
        });
    } else {
        res.status(200).json({
            data
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [173], () => (__webpack_exec__(3281)));
module.exports = __webpack_exports__;

})();