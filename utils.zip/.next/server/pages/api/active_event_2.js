"use strict";
(() => {
var exports = {};
exports.id = 512;
exports.ids = [512];
exports.modules = {

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6173);

async function handler(req, res) {
    const snapshot = await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].collection */ .Z.collection("event").doc("active event 2").get();
    if (snapshot.data() == null) {
        res.status(404).json({
            error: "Not Found Active Event"
        });
    } else {
        res.status(200).json(snapshot.data());
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [173], () => (__webpack_exec__(659)));
module.exports = __webpack_exports__;

})();