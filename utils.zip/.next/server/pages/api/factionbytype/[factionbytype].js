"use strict";
(() => {
var exports = {};
exports.id = 57;
exports.ids = [57];
exports.modules = {

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 2885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6173);

async function handler(req, res) {
    //Faction is data[0] Type is data[1]
    //Example /api/factionbytype/Eagle_Union&DD
    //EX.2 /api/factionbytype/Eagle%20Union&DD
    const { query: { factionbytype  } , method  } = req;
    const docfaction = factionbytype.replaceAll("_", " ");
    const myDoc = docfaction.split("&");
    const snapshot = await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].collection */ .Z.collection("ship").where("faction", "==", myDoc[0]).where("type", "==", myDoc[1]).get();
    if (snapshot.empty) {
        res.status(404).json({
            error: "Not Found Data"
        });
    } else {
        const data = [];
        snapshot.forEach((doc)=>{
            //console.log(doc.id, '=>', doc.data());
            data.push(doc.data());
        });
        if (data.length == 0) {
            res.status(404).json({
                error: "Not Found Data"
            });
        } else {
            res.status(200).json({
                data
            });
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [173], () => (__webpack_exec__(2885)));
module.exports = __webpack_exports__;

})();