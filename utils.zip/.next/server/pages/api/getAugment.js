"use strict";
(() => {
var exports = {};
exports.id = 201;
exports.ids = [201];
exports.modules = {

/***/ 2509:
/***/ ((module) => {

module.exports = require("firebase-admin");

/***/ }),

/***/ 9602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6173);

async function handler(req, res) {
    const snapshot = await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].collection */ .Z.collection("ship").where("augment", "!=", null).get();
    if (snapshot.empty) {
        res.status(404).json({
            error: "Not Found Data"
        });
    } else {
        const data = [];
        snapshot.forEach((doc)=>{
            //console.log(doc.id, '=>', doc.data());
            data.push(doc.data());
        });
        if (data.length == 0) {
            res.status(404).json({
                error: "Not Found Data"
            });
        } else {
            res.status(200).json({
                data
            });
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [173], () => (__webpack_exec__(9602)));
module.exports = __webpack_exports__;

})();