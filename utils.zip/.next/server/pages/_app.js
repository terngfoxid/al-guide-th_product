(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4260:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Footer() {
    function clearData() {
        const mode = localStorage.getItem("Mode");
        localStorage.clear();
        localStorage.setItem("Mode", mode ?? "light");
        window.location.reload();
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "footer",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
            className: "py-3 shadow-xl bg-neutral-300 dark:bg-neutral-800",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "px-1 py-1 mx-2 text-xs font-bold text-center duration-300 border border-transparent rounded bg-neutral-300 hover:bg-neutral-400 dark:bg-neutral-800 dark:hover:bg-neutral-600 hover:border-gray-400 dark:hover:border-gray-600 text-zinc-600 dark:text-zinc-400 hover:scale-110",
                        onClick: ()=>clearData(),
                        children: "ลบแคชเว็บไซต์"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col my-1 text-center text-zinc-600 dark:text-zinc-400",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-lg font-bold",
                            children: "\xa9 2022 Azur Lane Guide TH"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-xs italic",
                            children: "Made by SSTfoxide"
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 6555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ TopBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "styled-jsx/style"
const style_namespaceObject = require("styled-jsx/style");
var style_default = /*#__PURE__*/__webpack_require__.n(style_namespaceObject);
;// CONCATENATED MODULE: ./components/ThemeSwitcher.tsx



function ThemeSwitcher() {
    const [themeState, setThemeState] = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        let theme = localStorage.getItem("Mode");
        if (!theme) {
            theme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
        }
        setTheme(theme);
        setThemeState(theme);
    }, []);
    function setTheme(mode) {
        if (mode == "dark") {
            document.body.classList.add("dark");
            document.body.classList.remove("bg-neutral-100");
            document.body.classList.add("bg-neutral-900");
            localStorage.setItem("Mode", "dark");
            setThemeState("dark");
        }
        if (mode == "light") {
            document.body.classList.remove("dark");
            document.body.classList.remove("bg-neutral-900");
            document.body.classList.add("bg-neutral-100");
            localStorage.setItem("Mode", "light");
            setThemeState("light");
        }
    }
    function toggleTheme() {
        if (!themeState) return;
        localStorage.setItem("theme", themeState);
        if (themeState === "dark") {
            setTheme("light");
        } else {
            setTheme("dark");
        }
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
        onClick: ()=>toggleTheme(),
        className: "jsx-dac6d9b35053163e" + " " + `theme-switcher ${themeState}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                "aria-hidden": "true",
                viewBox: "0 0 24 24",
                className: "jsx-dac6d9b35053163e",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("mask", {
                        id: "theme-switcher-moon-mask",
                        className: "jsx-dac6d9b35053163e" + " " + "moon",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                x: "0",
                                y: "0",
                                width: "100%",
                                height: "100%",
                                fill: "white",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                cx: "24",
                                cy: "10",
                                r: "6",
                                fill: "black",
                                className: "jsx-dac6d9b35053163e"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                        cx: "12",
                        cy: "12",
                        r: "6",
                        mask: "url(#theme-switcher-moon-mask)",
                        fill: "currentColor",
                        className: "jsx-dac6d9b35053163e" + " " + "sun"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                        stroke: "currentColor",
                        strokeLinecap: "round",
                        strokeWidth: "2px",
                        className: "jsx-dac6d9b35053163e" + " " + "sun-beams",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "12",
                                y1: "1",
                                x2: "12",
                                y2: "3",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "12",
                                y1: "21",
                                x2: "12",
                                y2: "23",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "4.22",
                                y1: "4.22",
                                x2: "5.64",
                                y2: "5.64",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "18.36",
                                y1: "18.36",
                                x2: "19.78",
                                y2: "19.78",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "1",
                                y1: "12",
                                x2: "3",
                                y2: "12",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "21",
                                y1: "12",
                                x2: "23",
                                y2: "12",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "4.22",
                                y1: "19.78",
                                x2: "5.64",
                                y2: "18.36",
                                className: "jsx-dac6d9b35053163e"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("line", {
                                x1: "18.36",
                                y1: "5.64",
                                x2: "19.78",
                                y2: "4.22",
                                className: "jsx-dac6d9b35053163e"
                            })
                        ]
                    })
                ]
            }),
            jsx_runtime_.jsx((style_default()), {
                id: "dac6d9b35053163e",
                children: ".jsx-dac6d9b35053163e:where(.theme-switcher>svg){block-size:2rem}.jsx-dac6d9b35053163e:where(.theme-switcher) .jsx-dac6d9b35053163e:where(.sun,.moon,.sun-beams){-webkit-transform-origin:center center;-moz-transform-origin:center center;-ms-transform-origin:center center;-o-transform-origin:center center;transform-origin:center center}.jsx-dac6d9b35053163e:where(.theme-switcher) .jsx-dac6d9b35053163e:where(.sun,.sun-beams){color:hsl(40 95%50%)}.jsx-dac6d9b35053163e:where(.dark) .jsx-dac6d9b35053163e:where(.sun){color:hsl(0 0%100%)}.jsx-dac6d9b35053163e:where(.dark) .jsx-dac6d9b35053163e:where(.theme-switcher .sun){-webkit-transform:scale(1.5);-moz-transform:scale(1.5);-ms-transform:scale(1.5);-o-transform:scale(1.5);transform:scale(1.5)}.jsx-dac6d9b35053163e:where(.dark) .jsx-dac6d9b35053163e:where(.theme-switcher .sun-beams){opacity:0;-webkit-transform:rotate(-90deg);-moz-transform:rotate(-90deg);-ms-transform:rotate(-90deg);-o-transform:rotate(-90deg);transform:rotate(-90deg)}.jsx-dac6d9b35053163e:where(.dark) .jsx-dac6d9b35053163e:where(.theme-switcher .moon>circle){-webkit-transform:translate(-7px);-moz-transform:translate(-7px);-ms-transform:translate(-7px);-o-transform:translate(-7px);transform:translate(-7px)}@media(prefers-reduced-motion:no-preference){.jsx-dac6d9b35053163e:where(.theme-switcher) .jsx-dac6d9b35053163e:where(.sun,.sun-beams,.moon>circle){-webkit-transition:.5s cubic-bezier(.5,1.5,.75,1.25);-moz-transition:.5s cubic-bezier(.5,1.5,.75,1.25);-o-transition:.5s cubic-bezier(.5,1.5,.75,1.25);transition:.5s cubic-bezier(.5,1.5,.75,1.25)}}"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Topbar.tsx




function TopBar() {
    const [open, setOpen] = (0,external_react_.useState)(false);
    const menu = [
        {
            label: "ข้อมูลเรือ",
            path: "/ship"
        },
        {
            label: "กิจกรรม",
            path: "/active_event_slide"
        },
        {
            label: "ผู้จัดทำ",
            path: "/contact"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: "flex bg-neutral-200 dark:bg-neutral-800 text-zinc-600 dark:text-gray-300",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container flex items-center mx-auto",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-11/12 mx-auto flex flex-wrap lg:w-5/6 items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "h-16 flex items-center justify-between whitespace-nowrap text-2xl md:w-fit md:text-2xl lg:text-3xl",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: "Azur Lane Guide TH"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex order-2 md:order-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center order-1",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ThemeSwitcher, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                "aria-label": "menu",
                                className: "ml-4 md:hidden order-2 md:order-1",
                                onClick: ()=>setOpen((current)=>!current),
                                children: open ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-6 h-6 text-white",
                                    viewBox: "0 0 20 20",
                                    fill: "gray",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                    })
                                }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-6 h-6 text-white",
                                    fill: "gray",
                                    viewBox: "0 0 24 24",
                                    stroke: "gray",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M4 6h16M4 12h16M4 18h16"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        className: `basis-full order-3 md:order-2 md:basis-auto md:flex items-center justify-between text-center ${open ? "block" : "hidden"}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "gap-4 md:flex",
                            children: menu.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "transition rounded hover:bg-neutral-300 hover:dark:bg-neutral-600",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        onClick: ()=>setOpen(false),
                                        className: "block px-4 py-2",
                                        href: item.path,
                                        children: item.label
                                    })
                                }, `link-${item.label}`))
                        })
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 3847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _vercel_analytics_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9752);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Topbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6555);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4260);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_2__]);
_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function App({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_3__.NextSeo, {
                title: "Azur Lane Guide TH",
                description: "Azur Lane Guide for Thai's comunity,เว็บไซต์ที่จัดทำขึ้นเพื่อนสนับสนุนชุมชนของผู้การเกม Azur Lane ชาวไทย",
                openGraph: {
                    type: "website",
                    locale: "th_TH",
                    url: "https://al-guide-th.com",
                    siteName: "Azur Lane Guide TH"
                },
                additionalLinkTags: [
                    {
                        rel: "icon",
                        href: "/favicon.ico"
                    }
                ],
                additionalMetaTags: [
                    {
                        name: "keywords",
                        content: "azur,lane,guide,th,ไกด์,ไทย,ภาษาไทย,azur lane,azur lane guide th,อซูร์เลน,azur lane ไกด์,azur lane ภาษาไทย,สอนเล่น azur lane,ข้อมูลเรือ,ข้อมูลเรือ azur lane"
                    }
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Topbar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_vercel_analytics_react__WEBPACK_IMPORTED_MODULE_2__.Analytics, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_4___default()), {
                id: "callScript",
                strategy: "lazyOnload",
                src: "https://www.googletagmanager.com/gtag/js?id=G-L4CJGVFV5D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_4___default()), {
                id: "googleAnalytics",
                strategy: "lazyOnload",
                dangerouslySetInnerHTML: {
                    __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'G-L4CJGVFV5D', {
              page_path: window.location.pathname,
            });
          `
                }
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9752:
/***/ ((module) => {

"use strict";
module.exports = import("@vercel/analytics/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664], () => (__webpack_exec__(3847)));
module.exports = __webpack_exports__;

})();