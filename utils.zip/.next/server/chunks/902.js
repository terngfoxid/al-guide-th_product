exports.id = 902;
exports.ids = [902];
exports.modules = {

/***/ 9902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ActiveEventCard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/overlay/Loading.tsx
var Loading = __webpack_require__(6638);
;// CONCATENATED MODULE: ./components/overlay/Chibi_Event.tsx


function Chibi_Event(chibi) {
    const [state, setState] = (0,external_react_.useState)(3);
    const [textShow, setTextShow] = (0,external_react_.useState)(true);
    (0,external_react_.useEffect)(()=>{
        setTimeout(()=>{
            if (state == 1) setState(2);
            if (state == 2) setState(3);
            if (state == 3) setState(1);
        }, 15000);
    }, [
        state
    ]);
    const chibi_style = {
        set_overlay: "fixed bottom-5 left-0 md:bottom-5 md:left-5",
        chat_style: "animate__animated animate__fadeIn animate__slow flex bg-neutral-200 rounded-t-xl rounded-br-xl border-2 border-neutral-900 text-sm md:text-lg"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "EventChibi",
        className: chibi_style.set_overlay,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-items-start animate__animated animate__fadeInUp animate__slow",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-20 md:w-max",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "cursor-not-allowed",
                        src: chibi.chibi,
                        alt: "ship chibi image",
                        onClick: (event)=>{
                            if (textShow == true) setTextShow(false);
                            else {
                                setTextShow(true);
                            }
                        }
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "",
                    children: textShow == false ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}) : state == 1 ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mt-8 md:mt-16 h-max " + chibi_style.chat_style,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "px-1 py-1",
                                children: "กดคลิกที่รูปเพื่อขยายขนาดได้นะ"
                            })
                        })
                    }) : state == 2 ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mt-8 md:mt-16 h-max " + chibi_style.chat_style,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "px-1 py-1",
                                children: "ด่านแนะนำจะอยู่ด้านล่าง"
                            })
                        })
                    }) : state == 3 ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mt-8 md:mt-16 h-max " + chibi_style.chat_style,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "px-1 py-1",
                                children: "ปิดกล่องข้อความ กดที่ตัวจิบิ"
                            })
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/animate.css/animate.css
var animate = __webpack_require__(5544);
;// CONCATENATED MODULE: ./components/ActiveEventCard.tsx






function ActiveEventCard(props) {
    const [eventdata, setEventdata] = (0,external_react_.useState)({
        data: {
            banner: null,
            button: null,
            chibi: null,
            event_guide: null,
            newship: [],
            newship_chibi: [],
            newship_type: [],
            error: null,
            event_note_beginer: [],
            event_note_midgame: [],
            event_note_sp: [],
            event_note_sum: [],
            event_name: null,
            event_time: null,
            event_type: null,
            quest: [],
            special_furniture: null,
            special_frame: null,
            special_furniture_text: null,
            special_frame_text: null,
            special_furniture_text2: null,
            special_frame_text2: null
        }
    });
    let elementRef = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        const load = async ()=>{
            const data = await fetch("/api/" + props.eventType);
            const json = await data.json();
            setEventdata({
                data: json
            });
        };
        load().catch((err)=>console.log(err));
    }, []);
    if (eventdata.data.banner == null && eventdata.data.error == null) {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex justify-center p-5",
            children: /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {})
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-5 md:max-w-5/6 ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "banner",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "border border-gray-300 rounded-lg shadow-md bg-neutral-200 dark:border-gray-700 dark:bg-neutral-800",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "object-scale-down rounded-lg",
                        src: `https://drive.google.com/uc?export=view&id=${eventdata.data.banner}`,
                        alt: `${eventdata.data.banner} picture`
                    })
                })
            }),
            eventdata.data.newship.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "ships",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "p-3 border border-gray-300 rounded-lg shadow-md bg-neutral-200 dark:border-gray-700 dark:bg-neutral-800",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-3 text-center",
                            children: eventdata.data.event_type == null ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xl font-bold text-zinc-700 dark:text-zinc-300 md:text-2xl",
                                children: "เรือใหม่"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xl font-bold text-zinc-700 dark:text-zinc-300 md:text-2xl",
                                children: "เรือในกิจกรรม"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "grid grid-cols-2 gap-3 md:grid-cols-4",
                            children: eventdata.data.newship.map((newship, idx)=>{
                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "overflow-hidden duration-300 border-2 border-transparent rounded-lg shadow bg-neutral-300 dark:bg-neutral-700 hover:bg-neutral-400 dark:hover:bg-neutral-600 hover:scale-105 hover:border-cyan-400",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        className: "text-zinc-700 dark:text-zinc-300",
                                        href: `/ship/${newship}`,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center justify-start w-full py-1 sm:px-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: `/images/type/${eventdata.data.newship_type[idx]}.webp`,
                                                        alt: "ship type",
                                                        className: "w-[40px] sm:w-[50px]"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "w-full px-1 truncate md:px-3 sm:rounded-r-lg bg-neutral-400 dark:bg-neutral-600",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            children: eventdata.data.newship[idx]
                                                        })
                                                    })
                                                ]
                                            }),
                                            eventdata.data.newship_chibi[idx] != null && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex items-center justify-center w-full aspect-square md:aspect-video",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: eventdata.data.newship_chibi[idx],
                                                    alt: "ship chibi image"
                                                })
                                            })
                                        ]
                                    })
                                }, eventdata.data.newship[idx]);
                            })
                        })
                    ]
                })
            }),
            eventdata.data.quest.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "quest",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "p-3 border border-gray-300 rounded-lg shadow-md bg-neutral-200 dark:border-gray-700 dark:bg-neutral-800",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-3 text-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xl font-bold text-zinc-700 dark:text-zinc-300 md:text-2xl",
                                children: "เควสและของรางวัล"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid gap-3 mb-3 md:grid md:grid-cols-2",
                            children: [
                                eventdata.data.special_furniture != null && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex p-3 border border-gray-300 rounded-lg flex-cols dark:border-gray-700",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-3 w-fit",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                className: "w-32",
                                                src: eventdata.data.special_furniture
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex items-center justify-center flex-grow",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    eventdata.data.special_furniture_text && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "py-1 font-bold text-left text-zinc-700 dark:text-zinc-300 md:text-lg",
                                                        children: eventdata.data.special_furniture_text
                                                    }),
                                                    eventdata.data.special_furniture_text2 && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "py-1 text-left text-zinc-700 dark:text-zinc-300",
                                                        children: eventdata.data.special_furniture_text2
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                eventdata.data.special_frame != null && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex p-3 border border-gray-300 rounded-lg flex-cols dark:border-gray-700",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "px-3 w-fit",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                className: "w-32",
                                                src: eventdata.data.special_frame
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex items-center justify-center flex-grow",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    eventdata.data.special_frame_text && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "py-1 font-bold text-left text-zinc-700 dark:text-zinc-300 md:text-lg",
                                                        children: eventdata.data.special_frame_text
                                                    }),
                                                    eventdata.data.special_frame_text2 && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "py-1 text-left text-zinc-700 dark:text-zinc-300",
                                                        children: eventdata.data.special_frame_text2
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "p-5 border border-gray-300 rounded-lg dark:border-gray-700",
                            children: eventdata.data.quest.map((quest, idx)=>{
                                return /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "py-1 text-left text-zinc-700 dark:text-zinc-300",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            "▷",
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "px-2",
                                                children: quest
                                            })
                                        ]
                                    })
                                }, "quest" + idx);
                            })
                        })
                    ]
                })
            }),
            (eventdata.data.event_note_beginer.length > 0 || eventdata.data.event_note_midgame.length > 0 || eventdata.data.event_note_sp.length > 0 || eventdata.data.event_note_sum.length > 0) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "note",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "p-3 border border-gray-300 rounded-lg shadow-md bg-neutral-200 dark:border-gray-700 dark:bg-neutral-800",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mb-3 text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "text-xl font-bold text-zinc-700 dark:text-zinc-300 md:text-2xl",
                                    children: eventdata.data.event_type == null ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: "สรุปข้อมูลด่านน่าฟาร์มประจำ Event ใหม่"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: "สรุปข้อมูลด่านน่าฟาร์มประจำ Event"
                                    })
                                }),
                                eventdata.data.event_name != null && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "py-1 text-lg font-bold text-zinc-700 dark:text-zinc-300 md:text-xl",
                                    children: eventdata.data.event_name
                                }),
                                eventdata.data.event_time != null && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "py-1 font-bold text-zinc-700 dark:text-zinc-300 md:text-lg",
                                    children: eventdata.data.event_time
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "p-5 border border-gray-300 rounded-lg dark:border-gray-700",
                            children: [
                                eventdata.data.event_note_beginer.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mb-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-lg text-zinc-700 dark:text-zinc-300",
                                            children: "◆ ด่านน่าฟาร์ม (ผู้เล่นใหม่)"
                                        }),
                                        eventdata.data.event_note_beginer.map((note, idx)=>{
                                            return /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "py-1 text-zinc-700 dark:text-zinc-300",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex pl-3",
                                                    children: [
                                                        "-",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "px-2",
                                                            children: note
                                                        })
                                                    ]
                                                })
                                            }, "note_b" + idx);
                                        })
                                    ]
                                }),
                                eventdata.data.event_note_midgame.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mb-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-lg text-zinc-700 dark:text-zinc-300",
                                            children: "◆ ด่านน่าฟาร์ม (ผู้เล่นกลาง-เก่า)"
                                        }),
                                        eventdata.data.event_note_midgame.map((note, idx)=>{
                                            return /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "py-1 text-zinc-700 dark:text-zinc-300",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex pl-3",
                                                    children: [
                                                        "-",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "px-2",
                                                            children: note
                                                        })
                                                    ]
                                                })
                                            }, "note_m" + idx);
                                        })
                                    ]
                                }),
                                eventdata.data.event_note_sp.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mb-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-lg text-zinc-700 dark:text-zinc-300",
                                            children: "◆ ด่านSP"
                                        }),
                                        eventdata.data.event_note_sp.map((note, idx)=>{
                                            return /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "py-1 text-zinc-700 dark:text-zinc-300",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex pl-3",
                                                    children: [
                                                        "-",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "px-2",
                                                            children: note
                                                        })
                                                    ]
                                                })
                                            }, "note_sp" + idx);
                                        })
                                    ]
                                }),
                                eventdata.data.event_note_sum.length > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-lg text-zinc-700 dark:text-zinc-300",
                                            children: "◆ สรุปง่ายๆสั้นๆ"
                                        }),
                                        eventdata.data.event_note_sum.map((note, idx)=>{
                                            return /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "py-1 text-zinc-700 dark:text-zinc-300",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex pl-3",
                                                    children: [
                                                        "-",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "px-2",
                                                            children: note
                                                        })
                                                    ]
                                                })
                                            }, "note_sum" + idx);
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            eventdata.data.event_guide != null && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "guide",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "overflow-hidden border border-gray-300 rounded-lg shadow-md cursor-zoom-in bg-neutral-200 dark:border-gray-700 dark:bg-neutral-800",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: `https://drive.google.com/uc?export=view&id=${eventdata.data.event_guide}`,
                        alt: `${eventdata.data.banner} picture`,
                        ref: elementRef,
                        onClick: ()=>{
                            const element = document.getElementById("guide");
                            element.classList.toggle("overflow-scroll");
                            element.classList.toggle("fixed");
                            element.classList.toggle("inset-0");
                            [
                                "overflow-hidden",
                                "rounded-lg",
                                "w-full",
                                "h-full",
                                "flex",
                                "justify-center",
                                "items-center",
                                "cursor-zoom-in",
                                "cursor-zoom-out"
                            ].map((classes)=>element.children[0].classList.toggle(classes));
                            const imgRatio = elementRef.current.offsetWidth / elementRef.current.offsetHeight;
                            const winRatio = window.innerWidth / window.innerHeight;
                            elementRef.current.classList.toggle(imgRatio > winRatio ? "w-full" : "h-full");
                            element.scrollIntoView();
                            const chibi = document.getElementById("EventChibi");
                            chibi.classList.toggle("hidden");
                            const BTT = document.getElementById("BTT");
                            BTT.classList.toggle("hidden");
                        }
                    })
                })
            }),
            eventdata.data.chibi != null && /*#__PURE__*/ jsx_runtime_.jsx(Chibi_Event, {
                chibi: eventdata.data.chibi
            })
        ]
    });
}


/***/ }),

/***/ 5544:
/***/ (() => {



/***/ })

};
;