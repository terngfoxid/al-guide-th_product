"use strict";
exports.id = 328;
exports.ids = [328];
exports.modules = {

/***/ 6328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ Slide)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Slide = function({ children , style , className  }) {
    const element = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [slideIndex, setSlideIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [prevSlideIndex, setPrevSlideIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [touchX, setTouchX] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const slides = Array.isArray(children) ? children : [
        children
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative overflow-hidden rounded-lg shadow-xl bg-neutral-200 dark:bg-neutral-900",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex transition duration-300 ease-in-out flex-nowrap",
                style: {
                    transform: `translateX(-${slideIndex * 100}%)`
                },
                ref: element,
                children: slides.map((item, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `flex-shrink-0 w-full h-full ${className}`,
                        style: {
                            ...style
                        },
                        onTouchStart: (e)=>{
                            element.current?.classList.toggle("transition");
                            element.current?.classList.toggle("duration-300");
                            setTouchX(e.touches[0].clientX);
                            setPrevSlideIndex(slideIndex);
                        },
                        onTouchMove: (e)=>{
                            const deltaX = touchX - e.touches[0].clientX;
                            const percentScreen = deltaX / window.innerWidth * 1.5;
                            if (prevSlideIndex + percentScreen > 0 && prevSlideIndex + percentScreen < slides.length - 1) {
                                setSlideIndex(prevSlideIndex + percentScreen);
                            }
                        },
                        onTouchEnd: ()=>{
                            element.current?.classList.toggle("transition");
                            element.current?.classList.toggle("duration-300");
                            setSlideIndex((current)=>Math.round(current));
                        },
                        children: item
                    }, idx))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute left-0 right-0 text-center bottom-2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "px-4 rounded-full text-zinc-600 dark:text-zinc-400 bg-neutral-200 dark:bg-neutral-900 bg-opacity-80 dark:bg-opacity-80",
                    children: `${Math.round(Math.round(slideIndex + 1))} / ${slides.length}`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "absolute top-0 bottom-0 left-0 hidden p-2 transition sm:block text-zinc-600 dark:text-zinc-400 bg-neutral-200 dark:bg-neutral-900 bg-opacity-80 dark:bg-opacity-80 hover:bg-opacity-70 dark:hover:hover:bg-opacity-70",
                onClick: ()=>setSlideIndex((current)=>current - 1 < 0 ? slides.length - 1 : current - 1),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    strokeWidth: "3",
                    stroke: "currentColor",
                    className: "w-6 h-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M15.75 19.5L8.25 12l7.5-7.5"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "absolute top-0 bottom-0 right-0 hidden p-2 transition sm:block text-zinc-600 dark:text-zinc-400 bg-neutral-200 dark:bg-neutral-900 bg-opacity-80 dark:bg-opacity-80 hover:bg-opacity-70 dark:hover:hover:bg-opacity-70",
                onClick: ()=>setSlideIndex((current)=>current + 1 > slides.length - 1 ? 0 : current + 1),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    strokeWidth: "3",
                    stroke: "currentColor",
                    className: "w-6 h-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M8.25 4.5l7.5 7.5-7.5 7.5"
                    })
                })
            })
        ]
    });
};


/***/ })

};
;