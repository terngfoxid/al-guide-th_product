"use strict";
exports.id = 159;
exports.ids = [159];
exports.modules = {

/***/ 4260:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Footer() {
    const [dark, setDark] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.body.classList.add("overflow-x-hidden");
        if (localStorage.getItem("Mode") == "dark") {
            return setMode("dark");
        }
        if (localStorage.getItem("Mode") == "light") {
            return setMode("light");
        }
        if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
            return setMode("dark");
        }
        return setMode("light");
    }, []);
    function setMode(mode) {
        if (mode == "dark") {
            document.body.classList.add("dark");
            document.body.classList.remove("bg-neutral-100");
            document.body.classList.add("bg-neutral-900");
            localStorage.setItem("Mode", "dark");
            setDark(true);
        }
        if (mode == "light") {
            document.body.classList.remove("dark");
            document.body.classList.remove("bg-neutral-900");
            document.body.classList.add("bg-neutral-100");
            localStorage.setItem("Mode", "light");
            setDark(false);
        }
    }
    function clearData() {
        const mode = localStorage.getItem("Mode");
        localStorage.clear();
        localStorage.setItem("Mode", mode ?? "light");
        window.location.reload();
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "footer",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
            className: "py-3 shadow-xl bg-neutral-300 dark:bg-neutral-800",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "px-1 py-1 mx-2 text-xs font-bold text-center duration-300 border border-transparent rounded bg-neutral-300 hover:bg-neutral-400 dark:bg-neutral-800 dark:hover:bg-neutral-600 hover:border-gray-400 dark:hover:border-gray-600 text-zinc-600 dark:text-zinc-400 hover:scale-110",
                            onClick: ()=>dark ? setMode("light") : setMode("dark"),
                            children: dark ? "กลับสู่แสงสว่าง" : "เข้าสู่โลกมืด"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "px-1 py-1 mx-2 text-xs font-bold text-center duration-300 border border-transparent rounded bg-neutral-300 hover:bg-neutral-400 dark:bg-neutral-800 dark:hover:bg-neutral-600 hover:border-gray-400 dark:hover:border-gray-600 text-zinc-600 dark:text-zinc-400 hover:scale-110",
                            onClick: ()=>clearData(),
                            children: "ลบแคชเว็บไซต์"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col my-1 text-center text-zinc-600 dark:text-zinc-400",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-lg font-bold",
                            children: "\xa9 2022 Azur Lane Guide TH"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-xs italic",
                            children: "Made by SSTfoxide"
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 1098:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Topbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function Topbar() {
    const [navbar, setNavbar] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const topbar_style = {
        appname: "Azur Lane Guide TH",
        svg_appname: "",
        //------
        bar_style: "bg-neutral-200 shadow-xl dark:bg-neutral-800 w-full",
        appname_style: "text-2xl md:text-2xl lg:text-3xl text-zinc-600 font-bold my-1 px-2 dark:text-zinc-300",
        list_style: "block w-full h-full py-3 pl-3 pr-4 rounded no-underline text-center text-zinc-600 font-bold md:shadow-none hover:bg-neutral-300 hover:dark:bg-neutral-600 dark:text-gray-300 duration-300",
        smalldevice_style: "bg-neutral-200 w-full h-full items-center shadow md:shadow-none dark:bg-neutral-800 ",
        unhide_menu_style: "p-2 text-gray-700 rounded-md outline-none border-gray-300 border shadow"
    };
    //Menu Preset
    const menu_list = [];
    menu_list.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        className: "shadow md:shadow-none",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            className: topbar_style.list_style,
            href: "/ship",
            children: "ข้อมูลเรือ"
        })
    }));
    menu_list.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        className: "shadow md:shadow-none",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            className: topbar_style.list_style,
            href: "/active_event",
            children: "กิจกรรม"
        })
    }));
    menu_list.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        className: "shadow md:shadow-none",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            className: topbar_style.list_style,
            href: "/contact",
            children: "ผู้จัดทำ"
        })
    }));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "topbar",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: topbar_style.bar_style,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex items-center justify-center w-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex w-full h-full md:w-5/6 max-w-7xl",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full md:flex md:justify-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex justify-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-11/12 h-16 md:w-full",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-between block h-16",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                    href: "/",
                                                    className: "flex items-center h-full no-underline",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: topbar_style.appname_style,
                                                        children: "" + topbar_style.appname
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "md:hidden",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "",
                                                        onClick: ()=>setNavbar(!navbar),
                                                        "aria-label": "menu",
                                                        children: navbar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            className: "w-6 h-6 text-white",
                                                            viewBox: "0 0 20 20",
                                                            fill: "gray",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            className: "w-6 h-6 text-white",
                                                            fill: "gray",
                                                            viewBox: "0 0 24 24",
                                                            stroke: "gray",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M4 6h16M4 12h16M4 18h16"
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "items-center h-full m-0",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: navbar ? "flex-auto justify-self-center mt-0 block md:h-full md:items-center" : "hidden md:block md:h-full md:items-center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: topbar_style.smalldevice_style,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "items-center justify-center w-full h-full p-0 m-0 gap-x-2 md:flex md:space-x-10 md:space-y-0",
                                                children: menu_list
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
}


/***/ })

};
;