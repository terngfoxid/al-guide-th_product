"use strict";
exports.id = 173;
exports.ids = [173];
exports.modules = {

/***/ 6173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ db)
});

// EXTERNAL MODULE: external "firebase-admin"
var external_firebase_admin_ = __webpack_require__(2509);
var external_firebase_admin_default = /*#__PURE__*/__webpack_require__.n(external_firebase_admin_);
;// CONCATENATED MODULE: ./utils/db/serviceAccountKey.json
const serviceAccountKey_namespaceObject = JSON.parse('{"type":"service_account","project_id":"azur-lane-guide","private_key_id":"4130afb06d00b22d3028354cbd08df734c722138","private_key":"-----BEGIN PRIVATE KEY-----\\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC+rvhzdFElr58n\\nwuiC+pioMO7LSbxJYGoaoS5E7C9X1bKGVwQcxYbWObYIbjyySqYbkWsUT70Vafde\\nKCdjZN8ajPLI3RZnhzmmkZhAz5rxi7YZHlZgVnKQKn2XnYuKmuPuG3D0mLsJPqSV\\nnh8Gv3Wvn/Nw+MkasgPKV+9pfNxa/l+lgSHEolqBYV8DRttEt8gloTO8yK9Q4nNN\\nZ9tRAfxvWH0NpQx7Q4x4SSZ1Iqg+L3OcHAAlUq7RjzY1rUzcyOPSvJe/6UqwOo/h\\nyyO59Oo7pX4gaJFDoEKNMy8zK2ArqttEnBa6xXbDW4m3W6YUuzJAcD26zSSp6jsY\\nuHU6F+3XAgMBAAECggEAGYcHwJUdg/kQn9xqZOvdjK64WUNuzzf2xx01j4k7Bqbs\\n4SqRugmrn88BZ/wyE1WxCoHGSbrUanh8OFZnJ4RKkJ22pwi0xiQGph5ZuVt8Ym08\\nx1IWEuGf3AhZi0xOcROEA3gYVXaDm5zk9cQXDT/hJnjjDghltorcZ7YBWX2ba8bk\\n+GSES43wQAfZ+7IiO7R+NLRxhuEOdL9sGzJgCw8ISXYbYPNyEaMm1IehkVGOnvLq\\n915TtZ8rWMdNtmkLlPn5db2PTisMqUY4fYBKydoZywxcpWRvs1/h3yJw+WlkLybz\\nrTj9eLA+YFeOpCvhlYs6J5qpbxYVsgtv7FdM69HdkQKBgQDjJWyvHEK+1LPoMTIm\\npfZL5+D6F45xWGLYp7R2EQrMJ+bFI0v0C7fxLzIKzGybyuWq/sg5QB33PRkCJ2rG\\n15pPUJHyddVe8XJ5VwmhZ3G0SXx3o63uAowGmNJj+loXvNlIdXUySMPFAXfFR/Vx\\nlLzru0KvGWEzKbU4v/7mNYdc/wKBgQDW59BOb4wDaeoz/I0dzXfpAIuSOJlzV+ey\\nYVnwE7C2jXXgSWL6ABt2BkS19HbAy8AnBuUt8dCAJJBQMR2OECV+MghrE7fZX3qv\\nYrrPH/qlxaE4J93c4wBMXKvgPokWnplQKTmfvXDNmwG+WsPEbvfp51u5yGN88JQI\\nqk9zA1D3KQKBgD4tvHai8dJzP1xMO0JBJA7bRsavNBrq6wQLxGade6svMQi+BMil\\nfJDVLomuM/zhqcUJQZ4KYymO3A2u5JfR5TfZAlqwztvSlFeK7+PzATks9Jl7gN0q\\nbVJQ+ybLHWZqF8CyBobhTFXddP/YFuQkpyKQfEyaUfVDcYw7Ynd6J7fZAoGAYoTK\\n/eotKbN4ZnS0zKDRA8P4OAQydKor0Z7HeEPOkyGulC+QbEN4U1b0UOXNOv0tDbcf\\ngTyF9PjOH7Ukc2f7iCqvqUbU1ZXrzFNaiHGEmlJLYk8Eaqq2DEu/j4Gbnv7+Eb2U\\naSKTf+47kmRRss+cX2JsrnKrCS/Q7VgGLBetGmECgYBhSWwrs8OaOtL66uunDvlD\\nYdlN1R7RdWVAT8HoL1EqejNDQxbrlvRkXi+/dZY99BkZyquq81dExxNwpQ2fwVGp\\n3w8VSpV9kzOQHoCbZJ+z3NeFYkTcM2v/K6jzhTWs5Fpug/QjdkhWSJq9hR3G+OhQ\\nCjvu/d0P07Wkeg+GbIQtEA==\\n-----END PRIVATE KEY-----\\n","client_email":"firebase-adminsdk-359wp@azur-lane-guide.iam.gserviceaccount.com","client_id":"113921274027390294251","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_x509_cert_url":"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-359wp%40azur-lane-guide.iam.gserviceaccount.com"}');
;// CONCATENATED MODULE: ./utils/db/index.js


if (!(external_firebase_admin_default()).apps.length) {
    try {
        external_firebase_admin_default().initializeApp({
            credential: external_firebase_admin_default().credential.cert(serviceAccountKey_namespaceObject)
        });
    } catch (error) {
        console.log("Firebase admin initialization error", error.stack);
    }
}
/* harmony default export */ const db = (external_firebase_admin_default().firestore());


/***/ })

};
;